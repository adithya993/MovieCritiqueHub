package org.practiceprojects.adithya993.movies_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
